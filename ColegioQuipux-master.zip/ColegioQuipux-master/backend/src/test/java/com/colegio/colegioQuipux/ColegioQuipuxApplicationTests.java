package src.test.java.com.colegio.colegioQuipux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColegioQuipuxApplicationTests {

	@Test
	void contextLoads() {
	}

}
