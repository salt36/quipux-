package com.colegio.colegioQuipux.controllers;

import com.colegio.colegioQuipux.models.Estudiante;
import com.colegio.colegioQuipux.repositories.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class EstudianteController {

    @Autowired
    private EstudianteRepository estudianteRepository;

    @GetMapping("/getEstudiantes")
    public ResponseEntity<List<Estudiante>> getEstudiantes(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "6") int pageSize
    )  {
        Pageable pageable = PageRequest.of(page - 1, pageSize);
        Page<Estudiante> pageResult = estudianteRepository.findAll(pageable);

        List<Estudiante> estudiantes = pageResult.getContent();
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Last-Page", String.valueOf(pageResult.getTotalPages())); // Agregamos el encabezado personalizado

        return ResponseEntity.ok().headers(headers).body(estudiantes);
    }

    @GetMapping("/getEstudianteByIdentificacion/{identificacion}")
    public ResponseEntity<?> getEstudianteByIdentificacion(
            @PathVariable String identificacion
    )  {
        Estudiante estudiante = estudianteRepository.findByIdentificacion(identificacion);
        return ResponseEntity.ok().body(estudiante);
    }

}
