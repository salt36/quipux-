package com.colegio.colegioQuipux.models;

import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "Estudiantes")
public class Estudiante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_estudiante;

    private String identificacion;

    private String nombres;
}
