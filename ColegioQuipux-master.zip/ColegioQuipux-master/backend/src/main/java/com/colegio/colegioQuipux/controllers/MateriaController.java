package com.colegio.colegioQuipux.controllers;

import com.colegio.colegioQuipux.models.Estudiante;
import com.colegio.colegioQuipux.models.Materia;
import com.colegio.colegioQuipux.repositories.MateriasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MateriaController {

    @Autowired
    private MateriasRepository materiaRepository;

    @GetMapping("/getMaterias")
    public ResponseEntity<List<Materia>> getMaterias(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "6") int pageSize
    ) {
        Pageable pageable = PageRequest.of(page - 1, pageSize);
        Page<Materia> pageResult = materiaRepository.findAll(pageable);

        List<Materia> materias = pageResult.getContent();
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Last-Page", String.valueOf(pageResult.getTotalPages())); // Agregamos el encabezado personalizado

        return ResponseEntity.ok().headers(headers).body(materias);
    }

    @GetMapping("/getMateriaById/{id}")
    public ResponseEntity<?> getMateriaById(
            @PathVariable String id
    ) {
        Materia materia = materiaRepository.findById(Long.parseLong(id)).get();
        return ResponseEntity.ok().body(materia);
    }
}
