package com.colegio.colegioQuipux.repositories;

import com.colegio.colegioQuipux.models.Estudiante;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

@Repository
public interface EstudianteRepository extends CrudRepository<Estudiante, Long> {

    Page<Estudiante> findAll(Pageable pageable);

    Estudiante findByIdentificacion(String identificacion);
}
