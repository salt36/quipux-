package com.colegio.colegioQuipux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColegioQuipuxApplication {
	public static void main(String[] args) {
		SpringApplication.run(ColegioQuipuxApplication.class, args);
	}

}
