package com.colegio.colegioQuipux.models;

import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name="Materias")
public class Materia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_materia;

    private String nombre;

}
