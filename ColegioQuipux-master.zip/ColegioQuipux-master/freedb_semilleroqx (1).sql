-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-10-2023 a las 08:50:31
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `freedb_semilleroqx`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes`
--

CREATE TABLE `estudiantes` (
  `id_estudiante` int(11) NOT NULL,
  `identificacion` varchar(100) NOT NULL,
  `nombres` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estudiantes`
--

INSERT INTO `estudiantes` (`id_estudiante`, `identificacion`, `nombres`) VALUES
(1, '1037123061', 'Deiver Alonso Porras Alvarez prom 2023'),
(2, '1038098172', 'Samuel Serna Delgado'),
(3, '1018237621', 'David Santiago García Rodríguez'),
(4, '1020111738', 'Eilin Carrillo'),
(5, '1023630419', 'Angelly Zuluaga Serna'),
(6, '1018373081', 'Daruin Montoya Quiroz'),
(7, '1033777777', 'Miguel Marin'),
(8, '1025665353', 'Andrés Goez'),
(17, '1023630690', 'Juan Camilo Cardona Sánchez'),
(18, '1020417796', 'Henry Sepulveda Serna'),
(24, '2701216', 'Juan Sebastian Carneiro Prom 2023'),
(25, '1033184428', 'Camilo Aristizabal Calderón Prom 2023'),
(26, '1018236655', 'Yenifer Foronda Hernandez PROM 2023'),
(27, '1015070319', 'Juan Jose Restrepo Davila Prom 2023'),
(28, '1013460135', 'Miguel Angel Cardona Suarez prom 2023'),
(29, '1035974679', 'Juan Holguin Prom 2023'),
(30, '1025763198', 'Juan Franco Prom2023'),
(31, '1017273825', 'Diego Gonzalez PROM2023'),
(32, '1031542397', 'Jorge Andrés Ruiz Flores prom 2023'),
(33, '1032012479', 'Kevin Prom 2023'),
(34, '1032013511', 'Andrea Gonzalez Pineda PROM 2023'),
(35, '1035977576', 'sophia velasquez prom 2023'),
(36, '1023631923', 'Tomas Usme Prom 2023'),
(37, '1023525441', 'Juan bedoya PROM 2023'),
(38, '1033181705', 'Miguel Angel Sierra Ayala PROM 2023'),
(40, '1020111186', 'Juan Jose lopez PROM 2023'),
(41, '1023631597', 'Laura Rendon 2023'),
(44, '102564798', 'Camilo Molina'),
(56, '178383474', 'paola'),
(57, '1038101632', 'D Alejandra'),
(69, '1032013722', 'Schneider Mira'),
(77, '109290297', 'Samuel causil londoño'),
(95, '1034989172', 'Miguel Moreno Rojas prom2023'),
(96, '1032011720', 'Santiago Grajales '),
(99, '1025647244', 'Jonnier Grajales Alzate'),
(100, '1018235761', 'Juan Jose Diaz Rodriguez'),
(101, '1025647244', 'Jonnier Grajales Alzate'),
(102, '1011393864', 'Juan Gómez'),
(206, '1035853096', 'Paulina Rivera Palacio PROM 2023'),
(247, '1033179934', 'Tomás Buriticá'),
(333, '1015071255', 'Samuel Cañas'),
(777, '1033177390', 'Emmanuel Guerra'),
(888, '1018373081', 'Daruin Montoya Quiroz'),
(1929, '1020110500', 'Juan José García'),
(1983, '1042853355', 'Joel Andrés Mendoza'),
(2007, '1020113214', 'Tomas Minan Jaramillo'),
(2008, '1020112554', 'David Piedrahita Moncada PROM 2023'),
(2009, '1037776963', 'Mauricio Enrique Gutierrez Monsalve PROM 2023'),
(2311, '1018235368', 'Jojhan David Torres Tobon PROM2023');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materias`
--

CREATE TABLE `materias` (
  `id_materia` int(11) NOT NULL,
  `nombre` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `materias`
--

INSERT INTO `materias` (`id_materia`, `nombre`) VALUES
(1, 'Matematicas'),
(2, 'Español'),
(3, 'Fisica'),
(4, 'Geometria'),
(5, 'Ciencias naturales'),
(6, 'Historia'),
(7, 'Otra'),
(8, 'Programación'),
(10, 'Economia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materiasestudiantes`
--

CREATE TABLE `materiasestudiantes` (
  `id_estudiante` int(11) NOT NULL,
  `id_materia` int(11) NOT NULL,
  `nota` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `materiasestudiantes`
--

INSERT INTO `materiasestudiantes` (`id_estudiante`, `id_materia`, `nota`) VALUES
(1, 1, 3),
(1, 2, 4),
(1, 3, 2),
(5, 1, 4),
(5, 2, 4),
(5, 3, 3),
(6, 2, 4.5),
(8, 1, 5),
(8, 2, 4),
(8, 3, 5),
(8, 4, 4),
(8, 5, 4),
(8, 6, 4),
(8, 8, 5),
(8, 10, 5),
(18, 2, 5),
(18, 7, 4),
(18, 10, 4),
(77, 1, 3.875),
(77, 2, 4),
(77, 5, 5),
(77, 7, 4),
(77, 8, 4),
(95, 1, 4),
(95, 2, 5),
(95, 7, 3),
(101, 1, 5),
(101, 2, 3),
(101, 5, 3),
(101, 6, 2),
(101, 8, 5),
(102, 4, 5),
(1929, 1, 5),
(1929, 4, 4.8),
(1929, 8, 4.8),
(1983, 3, 4.5),
(1983, 5, 4),
(1983, 10, 5),
(2007, 3, 4),
(2007, 7, 5),
(2008, 1, 5),
(2008, 8, 4.8),
(2008, 10, 4),
(2009, 1, 4),
(2009, 8, 4.5),
(2009, 10, 3.7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notasxperiodo`
--

CREATE TABLE `notasxperiodo` (
  `id_estudiante` int(11) NOT NULL,
  `id_materia` int(11) NOT NULL,
  `Periodo` int(11) NOT NULL,
  `NotaPeriodo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `notasxperiodo`
--

INSERT INTO `notasxperiodo` (`id_estudiante`, `id_materia`, `Periodo`, `NotaPeriodo`) VALUES
(17, 2, 2, 4.8),
(17, 3, 2, 4.8),
(17, 8, 2, 5),
(2, 8, 1, 5),
(2, 1, 1, 4.8),
(2, 5, 1, 4.5),
(100, 1, 1, 5),
(101, 8, 3, 5),
(101, 8, 2, 5),
(101, 8, 1, 5),
(101, 8, 4, 5),
(100, 1, 2, 3.5),
(100, 1, 3, 4),
(100, 1, 4, 5),
(102, 8, 2, 3),
(102, 8, 1, 5),
(102, 8, 2, 3),
(102, 8, 4, 4),
(7, 1, 1, 4.5),
(7, 1, 2, 5),
(7, 1, 3, 5),
(7, 1, 4, 4),
(777, 1, 2, 4),
(777, 1, 2, 4),
(777, 1, 2, 4),
(69, 1, 2, 4.8),
(69, 8, 2, 5),
(96, 1, 2, 5),
(96, 8, 2, 4.5),
(333, 1, 1, 5),
(333, 2, 2, 4),
(333, 3, 3, 5),
(333, 4, 4, 4),
(247, 8, 3, 3),
(247, 8, 2, 4),
(2007, 3, 2, 3),
(2007, 3, 2, 4.7),
(247, 8, 2, 3.5),
(2007, 3, 2, 5),
(4, 10, 1, 4),
(44, 3, 1, 5),
(44, 3, 1, 5),
(44, 3, 1, 5),
(44, 3, 1, 4.2),
(44, 3, 1, 4.2),
(44, 3, 1, 4.2),
(95, 1, 1, 4.3),
(4, 10, 2, 5),
(20, 1, 1, 5),
(77, 1, 1, 1),
(20, 1, 2, 4.6),
(20, 1, 3, 4.8),
(20, 1, 4, 4.7),
(1929, 1, 1, 5),
(1929, 1, 2, 4.8),
(1929, 1, 3, 4.5),
(1929, 1, 4, 4.9),
(101, 1, 1, 3.2),
(101, 1, 2, 3.2),
(101, 1, 3, 3.2),
(101, 1, 4, 3.2),
(101, 2, 1, 3.9),
(101, 2, 2, 3.4),
(101, 2, 3, 4.4),
(101, 2, 4, 4.8),
(101, 5, 1, 3.2),
(101, 5, 2, 4),
(101, 5, 3, 3.9),
(101, 5, 4, 4.3),
(101, 6, 1, 3.1),
(101, 6, 2, 3.8),
(101, 6, 3, 4.2),
(101, 6, 4, 2.6),
(95, 1, 2, 4),
(95, 1, 3, 4.5),
(95, 1, 4, 3.8),
(95, 3, 1, 4.7),
(95, 3, 2, 4.1),
(95, 3, 3, 3.2),
(95, 3, 4, 3.9),
(18, 10, 2, 4),
(18, 2, 3, 4),
(18, 7, 1, 3),
(8, 1, 1, 4.5),
(8, 2, 2, 3.5),
(8, 3, 3, 5),
(8, 4, 4, 4),
(8, 5, 1, 2.5),
(8, 6, 2, 3.7),
(8, 8, 3, 5),
(8, 10, 2, 4.8),
(77, 1, 4, 4),
(77, 1, 4, 4),
(77, 1, 4, 4),
(77, 1, 4, 4),
(77, 1, 4, 4),
(77, 1, 4, 5),
(77, 1, 4, 5),
(69, 2, 2, 4.5),
(1, 1, 1, 4.5),
(5, 1, 1, 4),
(5, 1, 2, 5),
(5, 1, 3, 3),
(6, 2, 2, 4.5),
(6, 2, 2, 4.5),
(5, 1, 4, 4.5),
(5, 2, 1, 4.5),
(5, 2, 2, 4),
(5, 2, 3, 3.5),
(5, 2, 4, 5),
(5, 3, 1, 3),
(5, 3, 2, 3.5),
(5, 3, 3, 4),
(5, 3, 4, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD PRIMARY KEY (`id_estudiante`);

--
-- Indices de la tabla `materias`
--
ALTER TABLE `materias`
  ADD PRIMARY KEY (`id_materia`);

--
-- Indices de la tabla `materiasestudiantes`
--
ALTER TABLE `materiasestudiantes`
  ADD PRIMARY KEY (`id_estudiante`,`id_materia`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  MODIFY `id_estudiante` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2312;

--
-- AUTO_INCREMENT de la tabla `materias`
--
ALTER TABLE `materias`
  MODIFY `id_materia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
