import { Component, OnInit } from '@angular/core';
import { EstudiantesService } from 'src/app/_services/estudiantes.service';
import { MateriasService } from 'src/app/_services/materias.service';
import { Estudiante } from 'src/app/_models/estudiantes';
import { Materia } from 'src/app/_models/materias';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-admin-materias',
  templateUrl: './admin-materias.component.html',
  styleUrls: ['./admin-materias.component.css'],
})
export class AdminMateriasComponent implements OnInit {
  listaEstudiantes: Estudiante[] = [];
  listaMaterias: Materia[] = [];
  public page: number = 1;

  constructor(
    private estudiantesService: EstudiantesService,
    private materiaService: MateriasService
  ) {}

  ngOnInit(): void {
    this.estudiantesService
      .getEstudiantes()
      .pipe(first())
      .subscribe(
        (data) => {
          this.listaEstudiantes = data as unknown as Estudiante[]; 
        },
        (error) => {
          console.error('Error al obtener estudiantes:', error);
        }
      );


    this.materiaService
      .getMaterias()
      .pipe(first())
      .subscribe(
        (data) => {
          this.listaMaterias = data as unknown as Materia[];
        },
        (error) => {
          console.error('Error al obtener materias:', error);
        }
      );
  }
}
