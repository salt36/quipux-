import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Materia } from '../_models/materias';

@Injectable({
  providedIn: 'root'
})
export class MateriasService {
  constructor(private http: HttpClient) {}

  getMaterias(page: number = 1, pageSize: number = 100) {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    return this.http
      .get<{ materias: Materia[] }>('http://localhost:8080/getMaterias', { params })
      .pipe(
        map((response) => {
          console.log('Respuesta del servicio de materias:', response);
          return response;
        })
      );
  }
}
