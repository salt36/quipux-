import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Estudiante } from '../_models/estudiantes';

@Injectable({
  providedIn: 'root'
})
export class EstudiantesService {
  constructor(private http: HttpClient) {}

  getEstudiantes(page: number = 1, pageSize: number = 100) {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
  
    return this.http
      .get<{ estudiantes: Estudiante[] }>('http://localhost:8080/getEstudiantes', { params })
      .pipe(
        map((response) => {
          console.log('Respuesta del servicio:', response); // Agregar este log
          return response;
        })
      );
  }
  
}
