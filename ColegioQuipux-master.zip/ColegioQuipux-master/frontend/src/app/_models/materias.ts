export interface Materia {
    id_materia: number;
    nombre: string;
}