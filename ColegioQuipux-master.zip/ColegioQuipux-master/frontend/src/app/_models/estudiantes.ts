export interface Estudiante {
    id_estudiante: number;
    identificacion: string;
    nombres: string
}