export class MateriaInput {
    id_materia: number;
}
  