import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { APP_ROUTES } from './app.routes';
import { AdminMateriasComponent } from './components/admin-materias/admin-materias.component';
import { MateriasComponent } from './components/materias/materias.component';

const routes: Routes = [
  { path: '/adminMaterias', component: AdminMateriasComponent },
  { path: '/materias', component: MateriasComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(APP_ROUTES)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
